(() => {
  const DEFAULTS = {
    headline: "FORCE. CONTRÔLE. PROGRESSION.",
    intro: "Développe ta force, maîtrise ton poids du corps et progresse avec tes potes.",
    sessions: "Les exercices et horaires précis sont à confirmer avec l’organisation du club et le lycée.",
    drinks: "Plusieurs boissons et collations pourront être proposées à des prix bas, sous réserve de l’accord du lycée."
  };
  const $ = (id) => document.getElementById(id);
  const STORAGE_KEY = "liw_site_edits_v1";
  const readEdits = () => { try { return {...DEFAULTS, ...(JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}"))}; } catch { return {...DEFAULTS}; } };
  function applyEdits() {
    const data = readEdits();
    const headline = document.querySelector(".hero h1");
    headline.innerHTML = data.headline.split(" ").map((word, i) => {
      const clean = word.trim();
      if (!clean) return "";
      if (i === 1) return `<span>${escapeHtml(clean)}</span><br>`;
      return `${escapeHtml(clean)}${i < data.headline.split(" ").length-1 ? "<br>" : ""}`;
    }).join("");
    document.querySelector(".hero .lead").textContent = data.intro;
    document.querySelector("#seances .notice").textContent = data.sessions;
    document.querySelector("#boissons p:last-child").textContent = data.drinks;
  }
  function escapeHtml(str) { return String(str).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch])); }
  $("menuToggle").addEventListener("click", () => $("nav").classList.toggle("open"));
  document.querySelectorAll("#nav a").forEach(a => a.addEventListener("click", () => $("nav").classList.remove("open")));
  const modal = $("adminModal");
  $("adminOpen").addEventListener("click", () => { modal.hidden = false; $("adminCode").value = ""; $("loginBox").hidden = false; $("editorBox").hidden = true; });
  $("adminClose").addEventListener("click", () => modal.hidden = true);
  modal.addEventListener("click", e => { if (e.target === modal) modal.hidden = true; });
  $("loginBtn").addEventListener("click", () => {
    if ($("adminCode").value === "1109") {
      const d = readEdits();
      $("editHeadline").value = d.headline;
      $("editIntro").value = d.intro;
      $("editSessions").value = d.sessions;
      $("editDrinks").value = d.drinks;
      $("loginBox").hidden = true; $("editorBox").hidden = false;
    } else { alert("Code incorrect."); }
  });
  $("adminCode").addEventListener("keydown", e => { if (e.key === "Enter") $("loginBtn").click(); });
  $("saveBtn").addEventListener("click", () => {
    const d = {headline:$("editHeadline").value.trim() || DEFAULTS.headline, intro:$("editIntro").value.trim(), sessions:$("editSessions").value.trim(), drinks:$("editDrinks").value.trim()};
    localStorage.setItem(STORAGE_KEY, JSON.stringify(d)); applyEdits();
    $("saveStatus").textContent = "Enregistré dans ce navigateur. Pour publier ces changements pour tout le monde, il faut aussi mettre à jour les fichiers sur GitHub.";
  });
  $("resetBtn").addEventListener("click", () => { localStorage.removeItem(STORAGE_KEY); $("editHeadline").value=DEFAULTS.headline; $("editIntro").value=DEFAULTS.intro; $("editSessions").value=DEFAULTS.sessions; $("editDrinks").value=DEFAULTS.drinks; applyEdits(); $("saveStatus").textContent="Valeurs par défaut rétablies sur cet appareil."; });
  $("logoutBtn").addEventListener("click", () => { $("editorBox").hidden=true; $("loginBox").hidden=false; $("adminCode").value=""; });
  applyEdits();
})();